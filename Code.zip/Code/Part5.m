% Load the image 'cameraman.tif'
I = im2double(imresize(imread('cameraman.tif'), [128, 128]));

% Parameters for degradation
h_5x5 = fspecial('gaussian', [5, 5], 2); % 5x5 Gaussian filter with sigma = 2
h_7x7 = fspecial('gaussian', [7, 7], 2); % 7x7 Gaussian filter with sigma = 2
degraded_img_5x5= imfilter(I, h_5x5, 'conv', 'circular'); % circular convolution
degraded_img_7x7= imfilter(I, h_7x7, 'conv', 'circular'); % circular convolution
figure;%Plot the degarded noiseless image 
subplot(1, 4, 1);
imshow(degraded_img_5x5, []);
title({'Degraded Image 5x5 Gaussian Blur';'\sigma = 2'});
subplot(1, 4, 3);
imshow(degraded_img_7x7, []);
title({'Degraded Image 7x7 Gaussian Blur';'\sigma = 2'});

noise_var = 0.01; % Variance for Gaussian noise (20 dB equivalent)
% Degrade the image with Gaussian filter and additive Gaussian noise
I_degraded_5x5_noise = degraded_img_5x5 + sqrt(noise_var) * randn(size(I));
I_degraded_7x7_noise = degraded_img_5x5 + sqrt(noise_var) * randn(size(I));

% Inverse Filtering Restoration
figure;
subplot(2, 6, 1);
imshow(I_degraded_5x5_noise, []);
title({'Degraded Image 5x5 Gaussian ';'with noise'});

H_5x5 = psf2otf(h_5x5, size(I));
I_restoredfromnoiseless_inverse_5x5 = real(ifft2(fft2(degraded_img_5x5) ./ H_5x5));
subplot(2, 6, 3);
imshow(I_restoredfromnoiseless_inverse_5x5, []);
title({'Restored Image 5x5';' from blur image'});

I_restoredfromnoisy_inverse_5x5 = real(ifft2(fft2(I_degraded_5x5_noise) ./ H_5x5));
subplot(2, 6, 5);
imshow(I_restoredfromnoisy_inverse_5x5, []);
title({'Restored Image 5x5';' from noisy image'});

subplot(2, 6, 7);
imshow(I_degraded_7x7_noise, []);
title({'Degraded Image 7x7 Gaussian';'with noise'});

H_7x7 = psf2otf(h_7x7, size(I));
I_restored_inversefromnoiseless_7x7 = real(ifft2(fft2(degraded_img_7x7) ./ H_7x7));
subplot(2, 6, 9);
imshow(I_restored_inversefromnoiseless_7x7, []);
title({'Restored Image 7x7';'from blur image'});

I_restored_inversefromnoisy_7x7 = real(ifft2(fft2(I_degraded_7x7_noise) ./ H_7x7));
subplot(2, 6, 11);
imshow(I_restored_inversefromnoisy_7x7, []);
title({'Restored Image 7x7';'from noisy image'});

%% Wiener Filtering Restoration
% I_Wiener_blur_restored_5x5 = Wiener_Filtering(degraded_img_5x5,h_5x5);
% I_Wiener_blur_restored_7x7 = Wiener_Filtering(degraded_img_7x7,h_7x7);
% I_Wiener_noisy_restored_5x5 = Wiener_Filtering(I_degraded_5x5_noise,h_5x5);
% I_Wiener_noisy_restored_7x7 = Wiener_Filtering(I_degraded_7x7_noise,h_7x7);

% Smoothing Wiener Filter - w=SNR/(SNR+1)
I_Wiener_blur_restored_5x5 = ifft2((100/1+100)*fft2(degraded_img_5x5));
I_Wiener_blur_restored_7x7 = ifft2((100/1+100)*fft2(degraded_img_7x7));
I_Wiener_noisy_restored_5x5 = ifft2((100/1+100)*fft2(I_degraded_5x5_noise));
I_Wiener_noisy_restored_7x7 = ifft2((100/1+100)*fft2(I_degraded_7x7_noise));

% Display the restored images
figure;
subplot(2, 4, 1);
imshow(I_Wiener_blur_restored_5x5, []);
title('Wiener Restored from Blur Image, 5x5');

subplot(2, 4, 3);
imshow(I_Wiener_noisy_restored_5x5, []);
title('Wiener Restored from Noisy Image, 5x5');


subplot(2, 4, 5);
imshow(I_Wiener_blur_restored_7x7, []);
title('Wiener Restored from Blur Image, 7x7');

subplot(2, 4, 7);
imshow(I_Wiener_noisy_restored_7x7, []);
title('Wiener Restored from Noisy Image, 7x7');
