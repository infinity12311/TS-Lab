% Generate a sample 128x128 image
I = imresize(imread('cameraman.tif'), [128 128]);

% Add Gaussian noise to the image (standard deviation = 20)
I_noisy = imnoise(I, 'gaussian', 0, 0.01);

% Define block sizes to test (8x8 and 16x16)
block_sizes = [8, 16];
% Compression ratio target: 4:1 means we want to keep 1/4 of the coefficients
target_compression_ratio = 0.25;

% Loop through each block size and process both noiseless and noisy cases
for b = 1:length(block_sizes)
    block_size = block_sizes(b);
    
    % Process both noiseless and noisy versions of the image
    for noise_case = 1:2
        % Select the appropriate image
        if noise_case == 1
            current_image = I; % Noiseless case
            noise_title = 'Noiseless';
        else
            current_image = I_noisy; % Noisy case
            noise_title = 'Noisy';
        end
        
        % Get the size of the image
        [rows, cols] = size(current_image);
        
        % Pad the image if necessary to make it divisible by block size
        padded_rows = ceil(rows / block_size) * block_size;
        padded_cols = ceil(cols / block_size) * block_size;
        I_padded = padarray(current_image, [padded_rows - rows, padded_cols - cols], 'post');
        
        % Initialize the output image for reconstruction
        K_padded = zeros(size(I_padded));
        
        % Find an appropriate threshold to achieve 4:1 compression
        total_blocks = (padded_rows / block_size) * (padded_cols / block_size);
        total_coefficients = block_size * block_size * total_blocks;
        target_non_zero_coefficients = total_coefficients * target_compression_ratio;
        
        % Initial threshold and tolerance for adjusting
        threshold = 10; % Starting threshold value
        tolerance = 0.001; % Allow 5% deviation from the target compression ratio
        
        % Iteratively adjust threshold to achieve the target compression ratio
        while true
            non_zero_count = 0;
            
            % Loop through each block and count non-zero coefficients after thresholding
            for i = 1:block_size:padded_rows
                for j = 1:block_size:padded_cols
                    % Extract the current block
                    block = I_padded(i:i+block_size-1, j:j+block_size-1);
                    
                    % Compute the DCT of the block
                    D = dct2(block);
                    
                    % Apply the threshold
                    D_temp = D;
                    D_temp(abs(D_temp) < threshold) = 0;
                    
                    % Count the number of non-zero coefficients
                    non_zero_count = non_zero_count + nnz(D_temp);
                end
            end
            
            % Check if the number of non-zero coefficients is within target range
            compression_ratio = non_zero_count / total_coefficients;
            if abs(compression_ratio - target_compression_ratio) < tolerance
                break;
            elseif compression_ratio > target_compression_ratio
                threshold = threshold + 0.1; % Increase threshold to reduce non-zero coefficients
            else
                threshold = threshold - 0.1; % Decrease threshold to keep more non-zero coefficients
            end
        end

        % Display the selected threshold
        disp(['Selected Threshold for Block Size = ', num2str(block_size), ...
              ', Noise Case = ', noise_title, ' to achieve 4:1 with compression threshold= ', num2str(threshold), ', Real compression_ratio= ', num2str(compression_ratio)]);

        % Perform the compression with the selected threshold
        for i = 1:block_size:padded_rows
            for j = 1:block_size:padded_cols
                % Extract the current block
                block = I_padded(i:i+block_size-1, j:j+block_size-1);
                
                % Compute the DCT of the block
                D = dct2(block);
                
                % Apply the selected threshold
                D(abs(D) < threshold) = 0;
                
                % Compute the inverse DCT of the block
                K_block = idct2(D);
                
                % Store the processed block in the output image
                K_padded(i:i+block_size-1, j:j+block_size-1) = K_block;
            end
        end
        
        % Crop the padded image back to the original size
        K = K_padded(1:rows, 1:cols);
        
        % Normalize the reconstructed image for display
        K = K / 255;
        
        % Display the original and reconstructed images
        figure;
        subplot(1, 2, 1);
        imshow(current_image, []);
        title(['Original ', noise_title, ' Image']);
        
        subplot(1, 2, 2);
        imshow(K, []);
        title(['Reconstructed Image (Block Size = ', num2str(block_size), ')']);
    end
end

