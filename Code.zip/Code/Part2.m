% %------------------------------------------1--------------------------------
% % Load the image 'cameraman.tif'
% X = imread('cameraman.tif');
% 
% % Convert to grayscale if necessary
% if size(X, 3) == 3
%     I = rgb2gray(X);
% else
%     I = X;
% end
% 
% % Histogram equalization with different number of bins
% J = histeq(I, 32); % Histogram equalization with 32 bins
% K = histeq(I, 4);  % Histogram equalization with 4 bins
% 
% % Display the original image and the equalized images
% figure;
% 
% % Original image
% subplot(3, 3, 1);
% imshow(I);
% title('Original Image');
% 
% % Original histogram
% subplot(3, 3, 3);
% imhist(I);
% title('Histogram of Original Image');
% 
% % Equalized image with 32 bins
% subplot(3, 3, 4);
% imshow(J);
% title('Equalized Image (32 bins)');
% 
% % Histogram of image equalized with 32 bins
% subplot(3, 3, 6);
% imhist(J, 32);
% title('Histogram (32 bins)');
% 
% % Equalized image with 4 bins
% subplot(3, 3, 7);
% imshow(K);
% title('Equalized Image (4 bins)');
% 
% % Histogram of image equalized with 4 bins
% subplot(3, 3, 9);
% imhist(K, 4);
% title('Histogram (4 bins)');
% 
% % Adjust the layout for better visual appearance
% sgtitle('Histogram Equalization of "cameraman.tif" with Different Bins');

% %---------------------2----------------------------------
% % Load the image 'cameraman.tif'
% X = imread('cameraman.tif');
% 
% % Define a target histogram using a function (e.g., Gaussian distribution)
% % Here, the histogram has 256 bins, and we create a target distribution
% target_bins = 255;
% mu = 128; % Mean value for Gaussian
% sigma = 40; % Standard deviation for Gaussian
% target_hist = normpdf(0:target_bins, mu, sigma);
% target_hist = target_hist / sum(target_hist); % Normalize the histogram
% 
% % Histogram specification (modification)
% J = histeq(I, target_hist); % Apply the target histogram to the input image
% 
% % Display original and modified images
% figure;
% subplot(2, 2, 1);
% imshow(I);
% title('Original Image');
% 
% subplot(2, 2, 2);
% imhist(I);
% title('Original Histogram');
% 
% subplot(2, 2, 3);
% imshow(J);
% title('Image with Gaussian Histogram Modification');
% 
% subplot(2, 2, 4);
% imhist(J);
% title('Modified Image Histogram');

% %------------------------------3----------------------------------
% % Load the image 'trees.tif'
% X = imread('trees.tif');
% 
% % Convert to grayscale if necessary
% if size(X, 3) == 3
%     I = rgb2gray(X);
% else
%     I = X;
% end
% 
% figure;
% imshow(I);
% title('Original Image');
% % Edge detection using different methods
% figure;
% % Sobel method
% subplot(2, 2, 1);
% imshow(edge(I, 'sobel'));
% title('Sobel Edge Detection');
% 
% % Roberts method
% subplot(2, 2, 2);
% imshow(edge(I, 'roberts'));
% title('Roberts Edge Detection');
% 
% % Prewitt method
% subplot(2, 2, 3);
% imshow(edge(I, 'prewitt'));
% title('Prewitt Edge Detection');
% 
% % Laplacian of Gaussian (LoG) method
% subplot(2, 2, 4);
% imshow(edge(I, 'log'));
% title('LoG Edge Detection');
% 
% % Sobel filters for detecting 45° and -45° edges
% sobel_45 = [2 1 0; 1 0 -1; 0 -1 -2];  % 45° Sobel filter
% sobel_neg45 = [0 1 2; -1 0 1; -2 -1 0];  % -45° Sobel filter
% 
% % Apply the 45° and -45° Sobel filters
% edge_45 = imfilter(double(I), sobel_45, 'replicate');
% edge_neg45 = imfilter(double(I), sobel_neg45, 'replicate');
% 
% % Combine the results to highlight edges at both +45° and -45°
% combined_edges = abs(edge_45) + abs(edge_neg45);
% 
% % Thresholding to emphasize the edges
% threshold = 50; % Adjust threshold based on image quality
% combined_edges = combined_edges > threshold;
% 
% % Display the result
% figure;
% imshow(combined_edges);
% title('Edges at +/- 45° Angles');

%-------------------------------------4---------------------------------
% Load the image 'autumn.tif'
X = imread('autumn.tif');

% Convert to grayscale if necessary
if size(X, 3) == 3
    I = rgb2gray(X);
else
    I = X;
end

% Add salt & pepper noise to the image
J = imnoise(I, 'salt & pepper'); % The pixels are affected by noise

% Apply median filtering with a 3x3 neighbourhood
K_3x3 = medfilt2(J, [3 3]);

% Apply median filtering with a 5x5 neighbourhood
K_5x5 = medfilt2(J, [5 5]);

% Apply median filtering with a 7x7 neighbourhood
K_7x7 = medfilt2(J, [7 7]);

% Display the original, noisy, and filtered images
figure;

% Noisy image
subplot(2, 2, 1);
imshow(J);
title('Image with Salt & Pepper Noise');

% 3x3 median filtered image
subplot(2, 2, 2);
imshow(K_3x3);
title('Median Filtered (3x3)');

% 5x5 median filtered image
subplot(2, 2, 3);
imshow(K_5x5);
title('Median Filtered (5x5)');

% 7x7 median filtered image
subplot(2, 2, 4);
imshow(K_7x7);
title('Median Filtered (7x7)');

