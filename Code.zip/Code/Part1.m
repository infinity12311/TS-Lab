%%----------------------1----------------------------
% %% 1.a: Display the log magnitude of the FFT of one of the standard images
% % Load the image
 %img = imread('lighthouse.png');
% %img = imread('autumn.tif');
% if size(img, 3) == 3
%     img_gray = rgb2gray(img); % Convert to grayscale if it's a color image
% end
% 
% % Compute the FFT and display the log magnitude
% fft_img_gray = fft2(double(img_gray));
% fft_shifted = fftshift(fft_img_gray);
% log_magnitude = log(1 + abs(fft_shifted));
% 
% % Display the result
% figure;
% imshow(img);
% figure;
% imshow(log_magnitude, [], 'InitialMagnification', 'fit');
% title('Log Magnitude of the FFT of lighthouse.png');
% 
% % Plot the log magnitude of the FFT along the center row of the image
% center_row = size(log_magnitude, 1) / 2; % Find the center row index
% log_magnitude_row = log_magnitude(round(center_row), :); % Extract the middle row
% 
% % Plot the FFT log magnitude along this row
% figure;
% plot(log_magnitude_row);
% xlabel('Frequency Index');
% ylabel('Log Magnitude');
% title('Log Magnitude of the FFT along the Center Row of lighthouse');

% %% 1.b: Create an artificial image of a grid of impulses and repeat process
% % Create an artificial grid of impulses
% impulse_grid = zeros(size(img_gray));
% impulse_grid(1:20:end, 1:20:end) = 255; % Setting impulses at regular intervals
% 
% % Compute FFT of impulse grid and display the log magnitude
% fft_impulse = fft2(double(impulse_grid));
% fft_shifted_impulse = fftshift(fft_impulse);
% log_magnitude_impulse = log(1 + abs(fft_shifted_impulse));
% 
% % Plot the log magnitude of the FFT along the center row of the image
% center_row = size(log_magnitude_impulse, 1) / 2; % Find the center row index
% log_magnitude_impulse_row = log_magnitude_impulse(round(center_row), :); % Extract the middle row
% 
% % Display the result
% figure;
% imshow(impulse_grid);
% figure;
% plot(log_magnitude_impulse);
% xlabel('Frequency Index');
% ylabel('Log Magnitude');
% title('Log Magnitude of the FFT along the Center Row of impulse_grid');
% 
% % Repeat process with other regular periodic signal (sinusoidal)
% [x, y] = meshgrid(1:size(img, 2), 1:size(img, 1));
% periodic_signal = sin(2 * pi * 0.05 * x);
% 
% % Compute FFT of periodic signal and display the log magnitude
% fft_periodic = fft2(double(periodic_signal));
% fft_shifted_periodic = fftshift(fft_periodic);
% log_magnitude_periodic = log(1 + abs(fft_shifted_periodic));
% 
% % Plot the log magnitude of the FFT along the center row of the image
% center_row = size(log_magnitude_periodic, 1) / 2; % Find the center row index
% log_magnitude_periodic_row = log_magnitude_periodic(round(center_row), :); % Extract the middle row
% 
% % Display the result
% figure;
% imshow(periodic_signal);
% figure;
% plot(log_magnitude_periodic);
% xlabel('Frequency Index');
% ylabel('Log Magnitude');
% title('Log Magnitude of the FFT along the Center Row of log_magnitude_periodic');
% 
% % Repeat process with other non-periodic signal (random noise image)
% non_periodic_signal = rand(size(img_gray)) * 255; % Random noise in the range of 0-255 to simulate an image
% 
% % Compute the FFT of the non-periodic signal and display the log magnitude
% fft_non_periodic = fft2(double(non_periodic_signal));
% fft_shifted_non_periodic = fftshift(fft_non_periodic);
% log_magnitude_non_periodic = log(1 + abs(fft_shifted_non_periodic));
% 
% % Plot the log magnitude of the FFT along the center row of the image
% center_row = size(log_magnitude_non_periodic, 1) / 2; % Find the center row index
% log_magnitude_non_periodic_row = log_magnitude_non_periodic(round(center_row), :); % Extract the middle row
% 
% % Display the result
% figure;
% imshow(non_periodic_signal);
% figure;
% plot(log_magnitude_non_periodic_row);
% xlabel('Frequency Index');
% ylabel('Log Magnitude');
% title('Log Magnitude of the FFT along the Center Row of log_magnitude_non_periodic');

% 
% %% 1.c: Compute phase of FFT of image A and combine with amplitude of FFT of image B
% imgA = imread('lighthouse.png');
% imgB = imread('autumn.tif');
% % if size(imgA, 3) == 3
% %     imgA = rgb2gray(imgA); % Convert to grayscale if it's a color image
% % end
% % if size(imgB, 3) == 3
% %     imgB = rgb2gray(imgB); % Convert to grayscale if it's a color image
% % end
% 
% % Resize imgB to match the size of imgA
% imgB = imresize(imgB, size(imgA_gray));
% 
% % Compute FFT of both images
% fft_imgA = fft2(double(imgA));
% fft_imgB = fft2(double(imgB));
% 
% % Extract phase of image A and amplitude of image B
% phase_A = angle(fft_imgA);
% amplitude_B = abs(fft_imgB);
% 
% % Combine phase of A with amplitude of B
% combined_fft = amplitude_B .* exp(1i * phase_A);
% 
% % Compute the inverse FFT to form the new image
% new_image = ifft2(combined_fft);
% new_image_real = real(new_image);
% 
% % Display the new image
% figure;
% imshow(imgA, [], 'InitialMagnification', 'fit');
% title('Image A');
% figure;
% imshow(imgB, [], 'InitialMagnification', 'fit');
% title('Image B');
% figure;
% imshow(new_image_real, [], 'InitialMagnification', 'fit');
% title('New Image: Amplitude from Image B, Phase from Image A');

% %%----------------2------------
% %%2.a
% % Load the image 'autumn.tif'
% X = imread('autumn.tif');
% 
% % Convert the image to grayscale if it's a color image
% if size(X, 3) == 3
%     I = rgb2gray(X);
% else
%     I = X;
% end
% 
% % Compute the 2D Discrete Cosine Transform (DCT)
% J = dct2(I);
% 
% % Display the log magnitude of the DCT coefficients
% figure;
% colormap(jet(64));
% imagesc(log(abs(J) + 1)); % Add 1 to avoid log(0) issues
% colorbar;
% title('Log Magnitude of the 2D DCT of "autumn.tif"');
% 
% % Explanation:
% % The energy in the DCT domain is typically concentrated in the upper-left corner.
% % This is because DCT tends to compact most of the energy of natural images
% % into the low-frequency components, which appear in the top-left region of the DCT matrix.
% 
% % Compare with FFT
% % Compute the 2D FFT of the same image
% fft_img = fft2(double(I));
% %fft_shifted = fftshift(fft_img); % Shift the zero frequency to the center
% log_magnitude_fft = log(1 + abs(fft_img));
% 
% % Display the log magnitude of the FFT coefficients
% figure;
% colormap(jet(64));
% imagesc(log_magnitude_fft); % Add 1 to avoid log(0) issues
% colorbar;
% title('Log Magnitude of the FFT of "autumn.tif"');

%-----------------------3------------------------------
X = imread('autumn.tif');
% Convert the image to grayscale if it is a color image
if size(X, 3) == 3
    X_gray = rgb2gray(X);
else
    X_gray = X;
end

% Resize the image to be a power of 2 for Hadamard transform compatibility
% Hadamard transform requires that the size be a power of 2
[m, n] = size(X_gray);
m_pow2 = 2^nextpow2(m);
n_pow2 = 2^nextpow2(n);
X_resized = imresize(X_gray, [m_pow2, n_pow2]);

% Normalize the image values to be between 0 and 1
X_resized = double(X_resized) / 255;

% Compute the Hadamard transform using fwht (Fast Walsh-Hadamard Transform)
H = fwht(fwht(X_resized')');  % Apply fwht twice, on rows and then on columns

% Display the Hadamard transformed image
figure;
imagesc(H);
colormap('jet');
colorbar;
title('Hadamard Transform of the Image');

% Explanation:
% The Hadamard Transform is computed using the fwht function.
% It is efficient for certain types of images and produces a result where the energy is distributed across the entire image.

