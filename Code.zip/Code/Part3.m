% % Load the image 'autumn.tif'
% X = imread('autumn.tif');
% thresholds = 0:20:100;
% % Convert to grayscale if necessary
% if size(X, 3) == 3
%     I = rgb2gray(X);
% else
%     I = X;
% end
% 
% % Compute the DCT of the image
% J = dct2(I);
% 
% for i = 1:length(thresholds)
% nz = find(abs(J) < thresholds(i));
% J(nz) = 0;
% % Compute the inverse DCT to get the compressed image
% K = idct2(J);
% % Normalize the image for display
% K = K / 255;
% % Display the compressed image
% subplot(2, 3, i);
% imshow(K, []);
% title(['Compress Threshold = ', num2str(thresholds(i))]);
% end

%————————————————————————Differenrt blocks_-----------------------------------
% Load the image 'autumn.tif'
X = imread('autumn.tif');

% Convert to grayscale if necessary
if size(X, 3) == 3
    I = rgb2gray(X);
else
    I = X;
end

% Set the block sizes to test (8x8 and 16x16)
block_sizes = [4, 8, 16];
threshold = 60; % Set threshold for DCT coefficients

% Loop through each block size to perform the compression
for b = 1:length(block_sizes)
    block_size = block_sizes(b);
    
    % Get the size of the image
    [rows, cols] = size(I);
    
    % Pad the image if necessary to make it divisible by block size
    padded_rows = ceil(rows / block_size) * block_size;
    padded_cols = ceil(cols / block_size) * block_size;
    I_padded = padarray(I, [padded_rows - rows, padded_cols - cols], 'post');
    
    % Initialize output image
    K_padded = zeros(size(I_padded));
    
    % Loop through each block and apply DCT, thresholding, and IDCT
    for i = 1:block_size:padded_rows
        for j = 1:block_size:padded_cols
            % Extract the current block
            block = I_padded(i:i+block_size-1, j:j+block_size-1);
            
            % Compute the DCT of the block
            D = dct2(block);
            
            % Set DCT coefficients below the threshold to zero
            D(abs(D) < threshold) = 0;
            
            % Compute the inverse DCT of the block
            K_block = idct2(D);
            
            % Store the processed block in the output image
            K_padded(i:i+block_size-1, j:j+block_size-1) = K_block;
        end
    end
    
    % Crop the padded image back to the original size
    K = K_padded(1:rows, 1:cols);
    
    % Normalize the image for display
    K = K / 255;
    
    % Display the original and compressed images
    figure;
    subplot(1, 2, 1);
    imshow(I, []);
    title('Original Image');
    
    subplot(1, 2, 2);
    imshow(K, []);
    title(['Compressed Image with Block Size = ', num2str(block_size)]);
end
